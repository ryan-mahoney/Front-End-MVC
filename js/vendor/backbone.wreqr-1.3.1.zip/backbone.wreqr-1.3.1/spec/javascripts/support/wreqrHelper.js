(function(global){
  global.Wreqr = Backbone.Wreqr;
})(this);
